function StoridgeEventModel(data) {
  this.Time = data.time;
  this.Category = data.category;
  this.Module = data.module;
  this.Content = data.content;
}
