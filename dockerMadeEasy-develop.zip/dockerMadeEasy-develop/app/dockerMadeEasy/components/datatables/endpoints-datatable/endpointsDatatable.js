angular.module('dockerMadeEasy.app').component('endpointsDatatable', {
  templateUrl: 'app/dockerMadeEasy/components/datatables/endpoints-datatable/endpointsDatatable.html',
  controller: 'GenericDatatableController',
  bindings: {
    title: '@',
    titleIcon: '@',
    dataset: '<',
    tableKey: '@',
    orderBy: '@',
    reverseOrder: '<',
    showTextFilter: '<',
    endpointManagement: '<',
    accessManagement: '<',
    removeAction: '<'
  }
});
