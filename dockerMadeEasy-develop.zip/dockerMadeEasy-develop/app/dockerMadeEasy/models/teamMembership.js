function TeamMembershipModel(data) {
  this.Id = data.Id;
  this.UserId = data.UserID;
  this.TeamId = data.TeamID;
  this.Role = data.Role;
}
