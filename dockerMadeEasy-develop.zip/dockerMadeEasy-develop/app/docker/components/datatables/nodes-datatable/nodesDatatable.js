angular.module('dockerMadeEasy.docker').component('nodesDatatable', {
  templateUrl: 'app/docker/components/datatables/nodes-datatable/nodesDatatable.html',
  controller: 'GenericDatatableController',
  bindings: {
    title: '@',
    titleIcon: '@',
    dataset: '<',
    tableKey: '@',
    orderBy: '@',
    reverseOrder: '<',
    showTextFilter: '<',
    showIpAddressColumn: '<',
    accessToNodeDetails: '<'
  }
});
