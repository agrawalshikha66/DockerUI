package main // import "github.com/dockerMadeEasy/dockerMadeEasy"

import (
	"github.com/dockerMadeEasy/dockerMadeEasy"
	"github.com/dockerMadeEasy/dockerMadeEasy/bolt"
	"github.com/dockerMadeEasy/dockerMadeEasy/cli"
	"github.com/dockerMadeEasy/dockerMadeEasy/cron"
	"github.com/dockerMadeEasy/dockerMadeEasy/crypto"
	"github.com/dockerMadeEasy/dockerMadeEasy/exec"
	"github.com/dockerMadeEasy/dockerMadeEasy/filesystem"
	"github.com/dockerMadeEasy/dockerMadeEasy/git"
	"github.com/dockerMadeEasy/dockerMadeEasy/http"
	"github.com/dockerMadeEasy/dockerMadeEasy/jwt"
	"github.com/dockerMadeEasy/dockerMadeEasy/ldap"

	"log"
)

func initCLI() *dockerMadeEasy.CLIFlags {
	var cli dockerMadeEasy.CLIService = &cli.Service{}
	flags, err := cli.ParseFlags(dockerMadeEasy.APIVersion)
	if err != nil {
		log.Fatal(err)
	}

	err = cli.ValidateFlags(flags)
	if err != nil {
		log.Fatal(err)
	}
	return flags
}

func initFileService(dataStorePath string) dockerMadeEasy.FileService {
	fileService, err := filesystem.NewService(dataStorePath, "")
	if err != nil {
		log.Fatal(err)
	}
	return fileService
}

func initStore(dataStorePath string) *bolt.Store {
	store, err := bolt.NewStore(dataStorePath)
	if err != nil {
		log.Fatal(err)
	}

	err = store.Open()
	if err != nil {
		log.Fatal(err)
	}

	err = store.MigrateData()
	if err != nil {
		log.Fatal(err)
	}
	return store
}

func initStackManager(assetsPath string) dockerMadeEasy.StackManager {
	return exec.NewStackManager(assetsPath)
}

func initJWTService(authenticationEnabled bool) dockerMadeEasy.JWTService {
	if authenticationEnabled {
		jwtService, err := jwt.NewService()
		if err != nil {
			log.Fatal(err)
		}
		return jwtService
	}
	return nil
}

func initCryptoService() dockerMadeEasy.CryptoService {
	return &crypto.Service{}
}

func initLDAPService() dockerMadeEasy.LDAPService {
	return &ldap.Service{}
}

func initGitService() dockerMadeEasy.GitService {
	return &git.Service{}
}

func initEndpointWatcher(endpointService dockerMadeEasy.EndpointService, externalEnpointFile string, syncInterval string) bool {
	authorizeEndpointMgmt := true
	if externalEnpointFile != "" {
		authorizeEndpointMgmt = false
		log.Println("Using external endpoint definition. Endpoint management via the API will be disabled.")
		endpointWatcher := cron.NewWatcher(endpointService, syncInterval)
		err := endpointWatcher.WatchEndpointFile(externalEnpointFile)
		if err != nil {
			log.Fatal(err)
		}
	}
	return authorizeEndpointMgmt
}

func initStatus(authorizeEndpointMgmt bool, flags *dockerMadeEasy.CLIFlags) *dockerMadeEasy.Status {
	return &dockerMadeEasy.Status{
		Analytics:          !*flags.NoAnalytics,
		Authentication:     !*flags.NoAuth,
		EndpointManagement: authorizeEndpointMgmt,
		Version:            dockerMadeEasy.APIVersion,
	}
}

func initDockerHub(dockerHubService dockerMadeEasy.DockerHubService) error {
	_, err := dockerHubService.DockerHub()
	if err == dockerMadeEasy.ErrDockerHubNotFound {
		dockerhub := &dockerMadeEasy.DockerHub{
			Authentication: false,
			Username:       "",
			Password:       "",
		}
		return dockerHubService.StoreDockerHub(dockerhub)
	} else if err != nil {
		return err
	}

	return nil
}

func initSettings(settingsService dockerMadeEasy.SettingsService, flags *dockerMadeEasy.CLIFlags) error {
	_, err := settingsService.Settings()
	if err == dockerMadeEasy.ErrSettingsNotFound {
		settings := &dockerMadeEasy.Settings{
			LogoURL:                     *flags.Logo,
			DisplayDonationHeader:       true,
			DisplayExternalContributors: false,
			AuthenticationMethod:        dockerMadeEasy.AuthenticationInternal,
			LDAPSettings: dockerMadeEasy.LDAPSettings{
				TLSConfig: dockerMadeEasy.TLSConfiguration{},
				SearchSettings: []dockerMadeEasy.LDAPSearchSettings{
					dockerMadeEasy.LDAPSearchSettings{},
				},
			},
			AllowBindMountsForRegularUsers:     true,
			AllowPrivilegedModeForRegularUsers: true,
		}

		if *flags.Templates != "" {
			settings.TemplatesURL = *flags.Templates
		} else {
			settings.TemplatesURL = dockerMadeEasy.DefaultTemplatesURL
		}

		if *flags.Labels != nil {
			settings.BlackListedLabels = *flags.Labels
		} else {
			settings.BlackListedLabels = make([]dockerMadeEasy.Pair, 0)
		}

		return settingsService.StoreSettings(settings)
	} else if err != nil {
		return err
	}

	return nil
}

func retrieveFirstEndpointFromDatabase(endpointService dockerMadeEasy.EndpointService) *dockerMadeEasy.Endpoint {
	endpoints, err := endpointService.Endpoints()
	if err != nil {
		log.Fatal(err)
	}
	return &endpoints[0]
}

func main() {
	flags := initCLI()

	fileService := initFileService(*flags.Data)

	store := initStore(*flags.Data)
	defer store.Close()

	stackManager := initStackManager(*flags.Assets)

	jwtService := initJWTService(!*flags.NoAuth)

	cryptoService := initCryptoService()

	ldapService := initLDAPService()

	gitService := initGitService()

	authorizeEndpointMgmt := initEndpointWatcher(store.EndpointService, *flags.ExternalEndpoints, *flags.SyncInterval)

	err := initSettings(store.SettingsService, flags)
	if err != nil {
		log.Fatal(err)
	}

	err = initDockerHub(store.DockerHubService)
	if err != nil {
		log.Fatal(err)
	}

	applicationStatus := initStatus(authorizeEndpointMgmt, flags)

	if *flags.Endpoint != "" {
		endpoints, err := store.EndpointService.Endpoints()
		if err != nil {
			log.Fatal(err)
		}
		if len(endpoints) == 0 {
			endpoint := &dockerMadeEasy.Endpoint{
				Name: "primary",
				URL:  *flags.Endpoint,
				TLSConfig: dockerMadeEasy.TLSConfiguration{
					TLS:           *flags.TLSVerify,
					TLSSkipVerify: false,
					TLSCACertPath: *flags.TLSCacert,
					TLSCertPath:   *flags.TLSCert,
					TLSKeyPath:    *flags.TLSKey,
				},
				AuthorizedUsers: []dockerMadeEasy.UserID{},
				AuthorizedTeams: []dockerMadeEasy.TeamID{},
				Extensions:      []dockerMadeEasy.EndpointExtension{},
			}
			err = store.EndpointService.CreateEndpoint(endpoint)
			if err != nil {
				log.Fatal(err)
			}
		} else {
			log.Println("Instance already has defined endpoints. Skipping the endpoint defined via CLI.")
		}
	}

	adminPasswordHash := ""
	if *flags.AdminPasswordFile != "" {
		content, err := fileService.GetFileContent(*flags.AdminPasswordFile)
		if err != nil {
			log.Fatal(err)
		}
		adminPasswordHash, err = cryptoService.Hash(content)
		if err != nil {
			log.Fatal(err)
		}
	} else if *flags.AdminPassword != "" {
		adminPasswordHash = *flags.AdminPassword
	}

	if adminPasswordHash != "" {
		users, err := store.UserService.UsersByRole(dockerMadeEasy.AdministratorRole)
		if err != nil {
			log.Fatal(err)
		}

		if len(users) == 0 {
			log.Printf("Creating admin user with password hash %s", adminPasswordHash)
			user := &dockerMadeEasy.User{
				Username: "admin",
				Role:     dockerMadeEasy.AdministratorRole,
				Password: adminPasswordHash,
			}
			err := store.UserService.CreateUser(user)
			if err != nil {
				log.Fatal(err)
			}
		} else {
			log.Println("Instance already has an administrator user defined. Skipping admin password related flags.")
		}
	}

	var server dockerMadeEasy.Server = &http.Server{
		Status:                 applicationStatus,
		BindAddress:            *flags.Addr,
		AssetsPath:             *flags.Assets,
		AuthDisabled:           *flags.NoAuth,
		EndpointManagement:     authorizeEndpointMgmt,
		UserService:            store.UserService,
		TeamService:            store.TeamService,
		TeamMembershipService:  store.TeamMembershipService,
		EndpointService:        store.EndpointService,
		ResourceControlService: store.ResourceControlService,
		SettingsService:        store.SettingsService,
		RegistryService:        store.RegistryService,
		DockerHubService:       store.DockerHubService,
		StackService:           store.StackService,
		StackManager:           stackManager,
		CryptoService:          cryptoService,
		JWTService:             jwtService,
		FileService:            fileService,
		LDAPService:            ldapService,
		GitService:             gitService,
		SSL:                    *flags.SSL,
		SSLCert:                *flags.SSLCert,
		SSLKey:                 *flags.SSLKey,
	}

	log.Printf("Starting DockerMadeEasy %s on %s", dockerMadeEasy.APIVersion, *flags.Addr)
	err = server.Start()
	if err != nil {
		log.Fatal(err)
	}
}

