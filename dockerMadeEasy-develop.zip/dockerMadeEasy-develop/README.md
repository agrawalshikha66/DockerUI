
<p align="center">
  <img title="dockerMadeEasy" src='https://dockerMadeEasy.io/images/logo_alt.png' />
</p>

[![Docker Pulls](https://img.shields.io/docker/pulls/dockerMadeEasy/dockerMadeEasy.svg)](https://hub.docker.com/r/dockerMadeEasy/dockerMadeEasy/)
[![Microbadger](https://images.microbadger.com/badges/image/dockerMadeEasy/dockerMadeEasy.svg)](http://microbadger.com/images/dockerMadeEasy/dockerMadeEasy "Image size")
[![Documentation Status](https://readthedocs.org/projects/dockerMadeEasy/badge/?version=stable)](http://dockerMadeEasy.readthedocs.io/en/stable/?badge=stable)
[![Codefresh build status]( https://g.codefresh.io/api/badges/build?repoOwner=dockerMadeEasy&repoName=dockerMadeEasy&branch=develop&pipelineName=dockerMadeEasy-ci&accountName=deviantony&type=cf-1)]( https://g.codefresh.io/repositories/dockerMadeEasy/dockerMadeEasy/builds?filter=trigger:build;branch:develop;service:5922a08a3a1aab000116fcc6~dockerMadeEasy-ci)
[![Code Climate](https://codeclimate.com/github/dockerMadeEasy/dockerMadeEasy/badges/gpa.svg)](https://codeclimate.com/github/dockerMadeEasy/dockerMadeEasy)
[![Slack](https://dockerMadeEasy.io/slack/badge.svg)](https://dockerMadeEasy.io/slack/)
[![Gitter](https://badges.gitter.im/dockerMadeEasy/Lobby.svg)](https://gitter.im/dockerMadeEasy/Lobby?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge)
[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=YHXZJQNJQ36H6)

**_DockerMadeEasy_** is a lightweight management UI which allows you to **easily** manage your different Docker environments (Docker hosts or Swarm clusters).

**_DockerMadeEasy_** is meant to be as **simple** to deploy as it is to use. It consists of a single container that can run on any Docker engine (can be deployed as Linux container or a Windows native container).

**_DockerMadeEasy_** allows you to manage your Docker containers, images, volumes, networks and more ! It is compatible with the *standalone Docker* engine and with *Docker Swarm mode*.

## Demo

<img src="https://dockerMadeEasy.io/images/screenshots/dockerMadeEasy.gif" width="77%"/>

You can try out the public demo instance: http://demo.dockerMadeEasy.io/ (login with the username **admin** and the password **trydockerMadeEasy**).

Please note that the public demo cluster is **reset every 15min**.

Alternatively, you can deploy a copy of the demo stack inside a [play-with-docker (PWD)](https://labs.play-with-docker.com) playground:

- Browse [PWD/?stack=dockerMadeEasy-demo/play-with-docker/docker-stack.yml](http://play-with-docker.com/?stack=https://raw.githubusercontent.com/dockerMadeEasy/dockerMadeEasy-demo/master/play-with-docker/docker-stack.yml)
- Sign in with your [Docker ID](https://docs.docker.com/docker-id)
- Follow [these](https://github.com/dockerMadeEasy/dockerMadeEasy-demo/blob/master/play-with-docker/docker-stack.yml#L5-L8) steps.

Unlike the public demo, the playground sessions are deleted after 4 hours. Apart from that, all the settings are same, including default credentials.

## Getting started

* [Deploy DockerMadeEasy](https://dockerMadeEasy.readthedocs.io/en/latest/deployment.html)
* [Documentation](https://dockerMadeEasy.readthedocs.io)

## Getting help

* Issues: https://github.com/dockerMadeEasy/dockerMadeEasy/issues
* FAQ: https://dockerMadeEasy.readthedocs.io/en/latest/faq.html
* Slack (chat): https://dockerMadeEasy.io/slack/
* Gitter (chat): https://gitter.im/dockerMadeEasy/Lobby

## Reporting bugs and contributing

* Want to report a bug or request a feature? Please open [an issue](https://github.com/dockerMadeEasy/dockerMadeEasy/issues/new).
* Want to help us build **_dockerMadeEasy_**? Follow our [contribution guidelines](https://dockerMadeEasy.readthedocs.io/en/latest/contribute.html) to build it  locally and make a pull request. We need all the help we can get!

## Limitations

**_DockerMadeEasy_** has full support for the following Docker versions:

* Docker 1.10 to the latest version
* Docker Swarm >= 1.2.3

Partial support for the following Docker versions (some features may not be available):

* Docker 1.9
